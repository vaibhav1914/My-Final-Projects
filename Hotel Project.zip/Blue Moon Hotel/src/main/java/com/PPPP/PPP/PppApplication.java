package com.PPPP.PPP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PppApplication {

	public static void main(String[] args) {
		SpringApplication.run(PppApplication.class, args);
		System.out.println("Started.....");
	}

}
