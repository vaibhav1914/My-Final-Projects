package com.PPPP.PPP.Controller;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.PPPP.PPP.Model.Contactus;
import com.PPPP.PPP.Model.GitHub;
import com.PPPP.PPP.Model.RoomBooking;

@Controller
public class AdminController {

	@Autowired
	SessionFactory sf;

	@RequestMapping("/BlueMoonHotelManagerLogin")
	public ModelAndView manager() {
		return new ModelAndView("managerlogin");

	}

	@RequestMapping("/managerPage")
	public ModelAndView managerPage(@RequestParam String name, @RequestParam String pass) {
		if (name.equals("vaibhav") && pass.equals("1234")) {
			return new ModelAndView("viewTable");
		} else {
			return new ModelAndView("managerlogin");
		}

	}

	@RequestMapping("/viewtable")
	public ModelAndView viewTable() {
		return new ModelAndView("viewTable");
	}

	@RequestMapping("/viewtableDetails")
	public ModelAndView viewTableD() {

		Session ss = sf.openSession();
		Query query = ss.createQuery("from Contactus");
		List<Contactus> al = ((org.hibernate.query.Query) query).list();
		ModelAndView view = new ModelAndView();
		view.addObject("al", al);

		view.setViewName("comTable");
		return view;
	}

	@RequestMapping("/bookingDetails")
	public ModelAndView bookingDe() {
		Session ss = sf.openSession();
		Query query = ss.createQuery("from RoomBooking");
		List<RoomBooking> al = ((org.hibernate.query.Query) query).list();
		ModelAndView view = new ModelAndView();
		view.addObject("al1", al);
		view.setViewName("bookTable");
		return view;
	}
	
	@RequestMapping("/visitorsDetails")
	public ModelAndView visitors() {
		Session ss = sf.openSession();
		Query query = ss.createQuery("from GitHub");
		List<GitHub> al = ((org.hibernate.query.Query) query).list();
		ModelAndView view = new ModelAndView();
		view.addObject("al1", al);
		view.setViewName("visTable");
		return view;
	}

}
