package com.PPPP.PPP.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class GitHub {

	@Id
	private String pass;
	private String name;
	
	private long mnumber;

	public GitHub(String pass, String name, long mnumber) {
		super();
		this.pass = pass;
		this.name = name;
		this.mnumber = mnumber;
	}

	public GitHub() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "GitHub [pass=" + pass + ", name=" + name + ", mnumber=" + mnumber + "]";
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getMnumber() {
		return mnumber;
	}

	public void setMnumber(long mnumber) {
		this.mnumber = mnumber;
	}
	
	
	
}
