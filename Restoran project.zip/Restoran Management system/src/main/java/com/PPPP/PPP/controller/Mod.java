package com.PPPP.PPP.controller;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.PPPP.PPP.Entity.BookTable;
import com.PPPP.PPP.Entity.ContactUs;

@Controller
public class Mod {

	@Autowired
	SessionFactory sf;
	
	@RequestMapping("/")
	public ModelAndView hone() {
		return new ModelAndView("home");
	}
	@RequestMapping("/about")
	public ModelAndView about() {
		return new ModelAndView("about");
	}
	@RequestMapping("/services")
	public ModelAndView services() {
		return new ModelAndView("services");
	}
	@RequestMapping("/menu")
	public ModelAndView menu() {
		return new ModelAndView("menu");
	}
	@RequestMapping("/testimonial")
	public ModelAndView testimonial() {
		return new ModelAndView("testimonial");
	}
	@RequestMapping("/team")
	public ModelAndView team() {
		return new ModelAndView("team");
	}
	@RequestMapping("/booking")
	public ModelAndView booking() {
		return new ModelAndView("booking");
	}
	@RequestMapping("/contact")
	public ModelAndView contact() {
		return new ModelAndView("contact");
	}
	@RequestMapping("/bookingtableP")
	public ModelAndView bookingPage(@ModelAttribute BookTable booktable) {
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		ss.save(booktable);
		tx.commit();
		return new ModelAndView("home");
	}
	@RequestMapping("/contactPage")
	public ModelAndView contactPage(@ModelAttribute ContactUs contactus) {
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		ss.save(contactus);
		tx.commit();
		return new ModelAndView("contact");
	}
	
	
	
}
