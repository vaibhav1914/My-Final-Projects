package com.PPPP.PPP.controller;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import com.PPPP.PPP.Entity.BookTable;
import com.PPPP.PPP.Entity.ContactUs;

@Controller
public class ManagerController {

	@Autowired
	SessionFactory sf;
	

	@RequestMapping("/managerlogin")
	public ModelAndView manager() {
		return new ModelAndView("manager");

	}
	
	@RequestMapping("/managerPage")
	public ModelAndView managerPage(@RequestParam String name, @RequestParam String pass) {
		if (name.equals("vaibhav") && pass.equals("1234")) {
			return new ModelAndView("viewTable");
		} else {
			return new ModelAndView("viewTable");
		}
	}
	@RequestMapping("/viewtable")
	public ModelAndView viewTable() {
		return new ModelAndView("viewTable");
	}
	@RequestMapping("/bookingDetails")
	public ModelAndView bookingDe() {
		Session ss = sf.openSession();
		Query query = ss.createQuery("from BookTable");
		List<BookTable> al = ((org.hibernate.query.Query) query).list();
		ModelAndView view = new ModelAndView();
		view.addObject("al1", al);
		view.setViewName("bookTable");
		return view;
	}
	@RequestMapping("/message")
	public ModelAndView message() {
		Session ss = sf.openSession();
		Query query = ss.createQuery("from ContactUs");
		List<ContactUs> al = ((org.hibernate.query.Query) query).list();
		ModelAndView view = new ModelAndView();
		view.addObject("al2", al);
		view.setViewName("comTable");
		return view;
	}
}
