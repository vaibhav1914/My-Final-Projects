package com.PPPP.PPP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PppApplicationTests {

	@Test
	void contextLoads() {
	}

}
